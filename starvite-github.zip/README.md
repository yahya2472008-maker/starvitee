# Starvite

Undangan digital beranimasi bertema luar angkasa. Versi statis untuk GitHub Pages: satu file `index.html`, tanpa server.

- Buka situsnya, isi undangan, lalu di tab **Kirim** salin tautan. Tautan sudah memuat isi undangan, jadi tamu langsung melihat kartunya tanpa halaman editor.
- Tautan per tamu (dengan nama di kartu) dibuat dari **Daftar tamu**.
- Yang ikut di tautan: teks, tanggal, tempat, rangkaian acara, amplop digital, dan tautan musik YouTube.
- Yang tidak ikut: foto galeri dan file lagu yang diunggah (terlalu besar untuk tautan).
- Data editor tersimpan di browser pemilik, bukan di server.
